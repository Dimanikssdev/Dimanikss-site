# Dimanikss Website

Официальный сайт лаунчера Dimanikss (Minecraft 1.21.11).

## Как выложить на GitHub Pages

1. Создай репозиторий на GitHub (например `dimanikss-site`)
2. Залей все файлы из этой папки в репозиторий
3. Settings → Pages → Source: **Deploy from a branch**
4. Branch: `main` → folder `/ (root)` → Save
5. Через 1–2 минуты сайт будет по адресу:
   `https://ТВОЙ_НИК.github.io/dimanikss-site/`

## Файлы

- `index.html` — весь сайт

Premium: **250 ₽**
